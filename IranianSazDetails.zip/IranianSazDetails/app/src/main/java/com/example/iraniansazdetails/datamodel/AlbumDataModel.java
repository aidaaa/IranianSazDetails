package com.example.iraniansazdetails.datamodel;


import android.graphics.drawable.Drawable;


public class AlbumDataModel {
    private Drawable image;

    public Drawable getImage() {
        return image;
    }

    public void setImage(Drawable image) {
        this.image = image;
    }
}
