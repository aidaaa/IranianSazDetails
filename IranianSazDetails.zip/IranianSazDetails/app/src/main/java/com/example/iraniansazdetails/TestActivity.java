package com.example.iraniansazdetails;

import android.content.Context;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

public class TestActivity extends Fragment {

    View view;
    PlayerView music_player;
    SimpleExoPlayer exoPlayer;
    Context context;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.activity_test,container,false);
        music_player=view.findViewById(R.id.music_player);
        setUpview();
        return view;
    }

    private void setUpview() {
        String fileName="android.resource://"+context.getPackageName()+"/raw/surna";
        Uri uri=Uri.parse(fileName);

        TrackSelector trackSelector=new DefaultTrackSelector();
        exoPlayer= ExoPlayerFactory.newSimpleInstance(context,trackSelector);

        DataSource.Factory daFactory=new DefaultHttpDataSourceFactory(Util.getUserAgent(context,"exoplayer"));

        MediaSource mediaSource=new ExtractorMediaSource.Factory(daFactory).createMediaSource(uri);

        music_player.setPlayer(exoPlayer);

        exoPlayer.prepare(mediaSource);


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context=context;
        //setupMediaPlayer();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (!(isVisibleToUser))
        {
            if (exoPlayer.isPlaying()){
               exoPlayer.release();
               exoPlayer=null;
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (exoPlayer!=null) {
            exoPlayer.release();
            exoPlayer = null;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (exoPlayer==null){
            setUpview();
        }
    }
}
