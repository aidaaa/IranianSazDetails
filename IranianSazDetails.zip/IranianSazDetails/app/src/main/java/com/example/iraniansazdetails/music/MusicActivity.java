package com.example.iraniansazdetails.music;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.example.iraniansazdetails.R;

import java.io.IOException;
import java.sql.Time;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class MusicActivity extends Fragment {

    private SeekBar seekBar;
    private ImageView play,next,back;
    private TextView all,time;
    private MediaPlayer mediaPlayer=new MediaPlayer();
    private Timer timer;
    private View view;
    private Context context;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.activity_music,container,false);

        seekBar=view.findViewById(R.id.music_seekbar);
        play=view.findViewById(R.id.btn_play_music);
        next=view.findViewById(R.id.btn_next_music);
        back=view.findViewById(R.id.btn_back_music);
        all=view.findViewById(R.id.txt_all);
        time=view.findViewById(R.id.txt_time);

       setupMediaPlayer();
        return view;
    }


    private void setupMediaPlayer() {

        try {
            //mediaPlayer=new MediaPlayer();
            String fileName="android.resource://"+context.getPackageName()+"/raw/surna";
            mediaPlayer.setDataSource(context, Uri.parse(fileName));
            mediaPlayer.prepare();
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {
                    setUpView();
                }
            });


            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    if (view.isAttachedToWindow()) {
                        mediaPlayer.seekTo(0);
                        play.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.play, null));
                    }
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setUpView() {

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (mediaPlayer.isPlaying())
                    {
                        mediaPlayer.pause();
                        play.setImageDrawable(ResourcesCompat.getDrawable(getResources(),R.drawable.play,null));
                    }else {
                        mediaPlayer.start();
                        play.setImageDrawable(ResourcesCompat.getDrawable(getResources(),R.drawable.pause,null));
                        timer = new Timer();
                        timer.schedule(new MainTime(), 0, 1000);
                    }
                }catch (IllegalStateException e)
                {
                    System.out.println(e.getMessage()+"majid1");
                }

            }
        });
        all.setText(formatDuration(mediaPlayer.getDuration()));
        time.setText(formatDuration(0));

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.seekTo(mediaPlayer.getCurrentPosition()+5000);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.seekTo(mediaPlayer.getCurrentPosition()-5000);
            }
        });

        seekBar.setMax(mediaPlayer.getDuration());
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (b)
                {
                    mediaPlayer.seekTo(i);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

/*            timer = new Timer();
            timer.schedule(new MainTime(), 0, 1000);*/


    }

    private String formatDuration(long duration)
    {
        int second= (int) (duration/1000);
        int minutes=second/60;
        second%=60;
        return String.format(Locale.ENGLISH,"%02d",minutes)+":"+String.format(Locale.ENGLISH,"%02d",second);
    }

    public class MainTime extends TimerTask
    {
        @Override
        public void run() {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {

                    try {
                        seekBar.setProgress(mediaPlayer.getCurrentPosition());
                        time.setText(formatDuration(mediaPlayer.getCurrentPosition()));
                    }catch (IllegalStateException e)
                    {
                        System.out.println(e.getMessage()+"majid2");
                    }

                }
            });
        }
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context=context;
       //setupMediaPlayer();
    }

    public static MusicActivity newInstance() {
        
        Bundle args = new Bundle();
        
        MusicActivity fragment = new MusicActivity();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

      if (!(isVisibleToUser))
      {
                if (mediaPlayer.isPlaying()){
                if (timer != null) {
                    mediaPlayer.pause();
                //    mediaPlayer.release();
                   timer.purge();
                    timer.cancel();
                    play.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.play, null));
                }
                }
            }
        }

    @Override
    public void onPause() {
        super.onPause();
        if (mediaPlayer!=null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (mediaPlayer==null){
            setupMediaPlayer();
        }
    }
}

