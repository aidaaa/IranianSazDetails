package com.example.iraniansazdetails.video;

import android.content.Context;
import android.content.res.Configuration;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;

import com.example.iraniansazdetails.R;

import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class VideoActivity extends Fragment {

    private VideoView videoView;
    private Timer timer;
    private TextView videoCurrentDurationTextView;
    private SeekBar seekBar;
    private ImageView playButton, rewindButton;
    private ImageView forwardButton;
    private Context context;
    private FrameLayout frameLayout;
    private RelativeLayout.LayoutParams portraitLayoutParams;
    private RelativeLayout.LayoutParams landscapeLayoutParams;
    TextView videoDurationTextView;
    private View view;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.activity_video,container,false);
        videoView =view.findViewById(R.id.video_view);
        playButton = view.findViewById(R.id.play_button);
        forwardButton = view.findViewById(R.id.button_forward);
        rewindButton = view.findViewById(R.id.button_rewin);
        videoDurationTextView = view.findViewById(R.id.text_video_duration);
        videoCurrentDurationTextView = view.findViewById(R.id.text_video_current_duration);
        seekBar = view.findViewById(R.id.seek_bar);

        setIpVideoView();
        return view;
    }

    private void setIpVideoView() {
        String path="android.resource://" + context.getPackageName() + "/raw/video";
        videoView.setVideoURI(Uri.parse(path));
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                setUpView();
            }
        });

        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                if (view.isAttachedToWindow()) {
                    playButton.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.play, null));
                    videoView.seekTo(0);
                }
            }
        });
    }

    private void setUpView() {
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (videoView.isPlaying())
                {
                    videoView.pause();
                    playButton.setImageDrawable(ResourcesCompat.getDrawable(getResources(),R.drawable.play,null));
                }
                else
                {
                    videoView.start();
                    playButton.setImageDrawable(ResourcesCompat.getDrawable(getResources(),R.drawable.pause,null));
                    timer=new Timer();
                    timer.schedule(new MainTimer(),0,1000);
                }
            }
        });

        forwardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoView.seekTo(videoView.getCurrentPosition()+5000);
            }
        });
        rewindButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoView.seekTo(videoView.getCurrentPosition()-5000);
            }
        });

        videoDurationTextView.setText(formatDuration(videoView.getDuration()));
        videoCurrentDurationTextView.setText(formatDuration(0));

        seekBar.setMax(videoView.getDuration());
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (b){
                    videoView.seekTo(i);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }


    private String formatDuration(long duration) {
        int second = (int) (duration / 1000);
        int minutes = second / 60;
        second %= 60;
        return String.format(Locale.ENGLISH, "%02d", minutes) + ":" + String.format(Locale.ENGLISH, "%02d", second);
    }

    private class MainTimer extends TimerTask {

        @Override
        public void run() {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    seekBar.setProgress(videoView.getCurrentPosition());
                    videoCurrentDurationTextView.setText(formatDuration(videoView.getCurrentPosition()));
                    seekBar.setSecondaryProgress((videoView.getBufferPercentage() * videoView.getDuration()) / 100);
                }
            });
        }
    }


    public static VideoActivity newInstance() {
        
        Bundle args = new Bundle();
        
        VideoActivity fragment = new VideoActivity();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
            if (!(isVisibleToUser))
            {
                if (videoView!=null)
                {
                    if (videoView.isPlaying())
                    {
                        {
                            if (timer != null) {
                                videoView.pause();
                                timer.purge();
                                timer.cancel();
                                playButton.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.play, null));
                            }
                        }
                    }
                }
            }
        }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context=context;
    }
}

    /*   @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        frameLayout=findViewById(R.id.frame_root);
        if (newConfig.orientation== Configuration.ORIENTATION_PORTRAIT)
        {
            frameLayout.setLayoutParams(portraitLayoutParams);
            //yes status bar
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            frameLayout.setBackgroundColor(ContextCompat.getColor(this,R.color.white));
        }else {
            //full screen
            frameLayout.setLayoutParams(landscapeLayoutParams);
            //front of all component
            frameLayout.bringToFront();
            frameLayout.setBackgroundColor(ContextCompat.getColor(this,R.color.black));
            //no status bar
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }

    private void setupLayoutParams()
    {
        View toolbar=findViewById(R.id.toolbar);
        View mediaController=findViewById(R.id.layout_media_controller);
        landscapeLayoutParams=new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        portraitLayoutParams=new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        portraitLayoutParams.addRule(RelativeLayout.BELOW,toolbar.getId());
        portraitLayoutParams.addRule(RelativeLayout.ABOVE,mediaController.getId());
    }*/

