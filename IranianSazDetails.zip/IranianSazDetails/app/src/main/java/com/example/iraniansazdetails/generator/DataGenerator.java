package com.example.iraniansazdetails.generator;

import android.content.Context;
import android.support.v4.content.res.ResourcesCompat;

import com.example.iraniansazdetails.R;
import com.example.iraniansazdetails.datamodel.AlbumDataModel;

import java.util.ArrayList;
import java.util.List;

public class DataGenerator
{
    public static List<AlbumDataModel> getAlbumDataModel(Context context)
    {
        List<AlbumDataModel> models=new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            AlbumDataModel main=new AlbumDataModel();
            switch (i){
                case 0:
                    main.setImage(ResourcesCompat.getDrawable(context.getResources(),R.drawable.badi,null));
                    break;
                case 1:
                        main.setImage(ResourcesCompat.getDrawable(context.getResources(),R.drawable.badi1,null));
                    break;
                case 2:
                    main.setImage(ResourcesCompat.getDrawable(context.getResources(),R.drawable.badi2,null));
                    break;
                case 3:
                    main.setImage(ResourcesCompat.getDrawable(context.getResources(),R.drawable.badi3,null));
                    break;
                case 4:
                    main.setImage(ResourcesCompat.getDrawable(context.getResources(),R.drawable.badi4,null));
                    break;
                case 5:
                    main.setImage(ResourcesCompat.getDrawable(context.getResources(),R.drawable.badi5,null));
                    break;
                case 6:
                    main.setImage(ResourcesCompat.getDrawable(context.getResources(),R.drawable.badi6,null));
                    break;
                case 7:
                    main.setImage(ResourcesCompat.getDrawable(context.getResources(),R.drawable.badi,null));
                    break;
            }
            models.add(main);
        }
            return models;
    }
}
