package com.example.iraniansazdetails;

import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.iraniansazdetails.music.MusicActivity;
import com.example.iraniansazdetails.video.VideoActivity;
import com.example.iraniansazdetails.viewPager.ViewPagerAdapter;

public class MainActivity extends FragmentActivity {

    ViewPager viewPager;
    TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager=findViewById(R.id.viewpager);
        tabLayout=findViewById(R.id.tab);


        ViewPagerAdapter adapter=new ViewPagerAdapter(getSupportFragmentManager());
        adapter.notifyDataSetChanged();
        viewPager.setOffscreenPageLimit(0);
        viewPager.setAdapter(adapter);

        tabLayout.setupWithViewPager(viewPager);
        tabLayout.getTabAt(0).setIcon(R.drawable.music);
        tabLayout.getTabAt(1).setIcon(R.drawable.back);
        tabLayout.getTabAt(2).setIcon(R.drawable.vector);
        tabLayout.getTabAt(3).setIcon(R.drawable.video);

    }

}
